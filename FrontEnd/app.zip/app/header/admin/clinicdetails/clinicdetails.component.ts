import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-clinicdetails',
  templateUrl: './clinicdetails.component.html',
  styleUrls: ['./clinicdetails.component.css']
})
export class ClinicdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
