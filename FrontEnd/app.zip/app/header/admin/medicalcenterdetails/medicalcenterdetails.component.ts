import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-medicalcenterdetails',
  templateUrl: './medicalcenterdetails.component.html',
  styleUrls: ['./medicalcenterdetails.component.css']
})
export class MedicalcenterdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
