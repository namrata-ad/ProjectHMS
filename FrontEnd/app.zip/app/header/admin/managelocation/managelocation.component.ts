import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-managelocation',
  templateUrl: './managelocation.component.html',
  styleUrls: ['./managelocation.component.css']
})
export class ManagelocationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
