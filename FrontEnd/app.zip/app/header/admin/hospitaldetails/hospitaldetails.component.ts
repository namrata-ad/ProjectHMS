import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hospitaldetails',
  templateUrl: './hospitaldetails.component.html',
  styleUrls: ['./hospitaldetails.component.css']
})
export class HospitaldetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
