import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manageadditionaldetails',
  templateUrl: './manageadditionaldetails.component.html',
  styleUrls: ['./manageadditionaldetails.component.css']
})
export class ManageadditionaldetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
