import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-doctorappointmentdetails',
  templateUrl: './doctorappointmentdetails.component.html',
  styleUrls: ['./doctorappointmentdetails.component.css']
})
export class DoctorappointmentdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
